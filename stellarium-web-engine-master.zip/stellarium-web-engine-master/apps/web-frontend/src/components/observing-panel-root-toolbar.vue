// Stellarium Web - Copyright (c) 2022 - Stellarium Labs SRL
//
// This program is licensed under the terms of the GNU AGPL v3, or
// alternatively under a commercial licence.
//
// The terms of the AGPL v3 license can be found in the main directory of this
// repository.

<template>

<v-toolbar dark dense class="obspanel-toolbar">
  <v-btn icon to="/"><v-icon>mdi-close</v-icon></v-btn>
  <v-spacer></v-spacer>
</v-toolbar>

</template>

<script>
</script>

<style>
.obspanel-toolbar {
  background-color: #212121!important;
}
</style>
