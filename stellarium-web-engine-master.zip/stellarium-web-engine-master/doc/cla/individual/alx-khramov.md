Russian Federation, 2018-07-17

I hereby agree to the terms of the Stellarium Web Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Alexander Khramov alx.khramov@gmail.com https://github.com/alx-khramov
