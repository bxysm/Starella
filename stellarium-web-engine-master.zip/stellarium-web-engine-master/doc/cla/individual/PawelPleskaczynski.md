Poland, 2018-12-10

I hereby agree to the terms of the Stellarium Web Individual Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Paweł Pleskaczyński pawelpleskaczynski@gmail.com https://github.com/PawelPleskaczynski
