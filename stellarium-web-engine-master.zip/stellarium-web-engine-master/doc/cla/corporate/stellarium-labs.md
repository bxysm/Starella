France, 2018-07-17

Stellarium Labs SAS agrees to the terms of the Stellarium Web Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Fabien Chereau fabien.chereau@gmail.com https://github.com/xalioth

List of contributors:

Fabien Chereau fabien.chereau@gmail.com https://github.com/xalioth
